#!/bin/bash

# Install yum config file
sudo cp /home/vagrant/sync/etc/yum.repos.d/rhel_dvd.repo /etc/yum.repos.d/rhel_dvd.repo
